package edu.wmich.cs1120.games;

import java.util.Random;

/**
 * From SOWJ, p. 357
 * @author SOWJ
 *
 */
public class Dice {
	private int sides;
	private int value;
	
	public Dice(int numSides) {
		sides = numSides;
		roll();
	}
	
	public void roll() {
		Random rand = new Random();
		value = rand.nextInt(sides) + 1;
		
	}
	
	public int getSides() {
		return sides;
	}
	
	public int getValue() {
		return value;
	}

}
